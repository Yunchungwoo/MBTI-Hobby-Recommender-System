import React, { useState } from "react";
import "./FindtoIDstyle.css";

// 이미지 파일 import
import Rectangle1 from "../img/rectangle-398.svg";
import Rectangle2 from "../img/rectangle-400.svg";
import maskImg from "../img/mask-group.png";
import line from "../img/line-8.svg";

const FindtoID = () => {
  const [selectedButton, setSelectedButton] = useState("PASS");
  const [infoText, setInfoText] = useState("본인확인 방법을 선택해주세요.");

  // 버튼 클릭 시, 이미 선택된 버튼이면 동작 제어 함수
  const handleButtonClick = (button) => {
    if (selectedButton !== button) {
      setSelectedButton(button);
      setInfoText(
        button === "ID"
          ? "하비ID를 찾기 위한 본인인증 방법을 선택해주세요"
          : "본인확인 방법을 선택해주세요."
      );
    }
  };

  return (
    <div className="FindtoID">
      <div className="FindtoID-2">
        <div className="FindtoID-groupbox">
          <div className="FindtoID-selected">
            <div className="FindtoID-container">

              {/* ID 찾기 버튼 */}
              <img
                className="select-btn-id"
                alt="Rectangle"
                src={selectedButton === "ID" ? Rectangle1 : Rectangle2}
                onClick={() => handleButtonClick("ID")}
                style={{ cursor: selectedButton === "ID" ? "default" : "pointer" }}
              />

              {/* 비밀번호 찾기 버튼 */}
              <img
                className="select-btn-pass"
                alt="Rectangle"
                src={selectedButton === "PASS" ? Rectangle1 : Rectangle2}
                onClick={() => handleButtonClick("PASS")}
                style={{ cursor: selectedButton === "PASS" ? "default" : "pointer" }}
              />

              {/* 텍스트 색상 변경*/}
              <div
                className={`select-btn-id-text ${
                  selectedButton === "ID" ? "selected-text" : "deselected-text"
                }`}
                onClick={() => handleButtonClick("ID")}
                style={{ cursor: selectedButton === "ID" ? "default" : "pointer" }}
              >
                ID 찾기
              </div>
              <div
                className={`select-btn-pass-text ${
                  selectedButton === "PASS" ? "selected-text" : "deselected-text"
                }`}
                onClick={() => handleButtonClick("PASS")}
                style={{ cursor: selectedButton === "PASS" ? "default" : "pointer" }}
              >
                비밀번호 찾기
              </div>
            </div>
          </div>

          {/* 휴대폰 인증 박스 */}
          <div className="authentication-box-number" />
          <div className="authentication-box-email" />
          <div className="authentication-box-number-group1">
            <div className="authentication-box-number-group2">
              <div className="authentication-box-text">휴대폰 인증</div>
              <div className="authentication-box-number-text">
                회원님 명의의 휴대폰으로 인증
              </div>
            </div>
          </div>

          {/* 이메일 인증 박스 */}
          <div className="authentication-box-email-group1">
            <div className="authentication-box-email-group2">
              <div className="authentication-box-text">이메일 인증</div>
              <div className="authentication-box-email-text">
                회원님 소유의 이메일로 인증
              </div>
            </div>
          </div>

          {/* 인증하기 버튼 */}
          <div className="authentication-btn-email" />
          <div className="authentication-btn-number" />
          <div className="authentication-btn-email-text">
            <a href="#">인증하기</a>
          </div>
          <div className="authentication-btn-number-text">
            <a href="#">인증하기</a>
          </div>
          <div className="authentication-btn-email-maskImg" />
          <img
            className="authentication-btn-number-maskImg"
            alt="Mask group"
            src={maskImg}
          />
          {/* 텍스트가 동적으로 변경되는 p 태그 */}
          <p className="p">{infoText}</p>
          <img className="line" alt="Line" src={line} />
        </div>
      </div>
    </div>
  );
};

export default FindtoID;
