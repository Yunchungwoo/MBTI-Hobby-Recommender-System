import React, { useState } from "react";
import "./mbtiu40intju41-1.css";
import "./styleguide.css";
import "./globals.css";

const MBTIPage_INTJ = () => {
  const [currentTab, setCurrentTab] = useState(1);

  const showTab = (tabIndex) => {
    setCurrentTab(tabIndex);
  };

  return (
    <div className="container-center-horizontal">
      <div className="mbtiu40intju41-1 screen">
        <div className="overlap-group-3">
          <div className="explore-hobby notosanskr-black-black-30px">Explore HOBBY</div>
        </div>
        <header className="header">
          <div className="overlap-group2">
            <div className="banner-background-vectors">
              <div className="background-ellipse-container">
                <div className="background-ellipse-4"></div>
                <div className="background-ellipse"></div>
              </div>
              <div className="grou-container">
                <div className="background-ellipse-container-1">
                  <div className="background-ellipse-1"></div>
                  <div className="background-ellipse-2"></div>
                </div>
                <div className="background-ellipse-7"></div>
                <div className="background-ellipse-3"></div>
                <div className="background-ellipse"></div>
              </div>
            </div>
            <div className="typograhpy-1 typograhpy notosanskr-bold-white-100-8px">I</div>
            <div className="typograhpy-2 typograhpy notosanskr-bold-white-100-8px">N</div>
            <div className="typograhpy-3 typograhpy notosanskr-bold-white-100-8px">T</div>
            <div className="typograhpy-4 typograhpy notosanskr-bold-white-100-8px">J</div>
            <h1 className="banner-title banner notosanskr-bold-white-100-8px">MBTI</h1>
            <div className="banner-subtitle banner notosanskr-bold-white-80px">INTJ</div>
            <p className="banner-info banner notosanskr-medium-white-24px">
              모든 일에 게획을 세우며 상상력이 풍부한 성격 <br />유형입니다.
            </p>
          </div>
        </header>

        <div className="overlap-group9">
          <div className="rectangle-20"></div>
          <div className="main">
            <div className="overlap-group1">
              <div className="main-content1-title notosanskr-bold-black-50px">성향 요약</div>
              <div className="main-content-chart-container">
                <div className="main-content1-chart1">
                  <div className="overlap-group">
                    <div className="ellipse-97"></div>
                    <img className="ellipse-98" src="img/ellipse-98.svg" alt="Ellipse 98" />
                    <img className="ellipse-99" src="img/ellipse-99.svg" alt="Ellipse 99" />
                    <img className="ellipse-100" src="img/ellipse-100.svg" alt="Ellipse 100" />
                    <div className="e azeretmono-bold-licorice-80px">E</div>
                    <div className="i azeretmono-bold-black-80px">I</div>
                  </div>
                  <div className="main-content1-subtitle azeretmono-semi-bold-black-32px">판단적</div>
                </div>
                <div className="main-content1-chart2">
                  <div className="overlap-group-1">
                    <div className="ellipse-97"></div>
                    <img className="ellipse-98" src="img/ellipse-98-1.svg" alt="Ellipse 98" />
                    <img className="ellipse-99" src="img/ellipse-99.svg" alt="Ellipse 99" />
                    <img className="ellipse-100" src="img/ellipse-100.svg" alt="Ellipse 100" />
                    <div className="price azeretmono-bold-licorice-80px">S</div>
                    <div className="n azeretmono-bold-black-80px">N</div>
                  </div>
                  <div className="main-content1-subtitle-1 azeretmono-semi-bold-black-32px">직관적</div>
                </div>
              </div>
            </div>

            <div className="overlap-group8">
              <div className="bookmarkbar">
                <div className={currentTab === 1 ? "overlap-group3" : "overlap-group-2"}>
                  <div
                    className={currentTab === 1 ? "boockmark-title-1 valign-text-middle notosanskr-bold-blueberry-35px" : "boockmark-title valign-text-middle notosanskr-bold-blueberry-35px"}
                    onClick={() => showTab(1)}
                  >
                    소개
                  </div>
                </div>
                <div className={currentTab === 2 ? "overlap-group3" : "overlap-group-2"}>
                  <div
                    className={currentTab === 2 ? "boockmark-title-1 valign-text-middle notosanskr-bold-blueberry-35px" : "boockmark-title valign-text-middle notosanskr-bold-blueberry-35px"}
                    onClick={() => showTab(2)}
                  >
                    개척자 정신
                  </div>
                </div>
                <div className={currentTab === 3 ? "overlap-group3" : "overlap-group-2"}>
                  <div
                    className={currentTab === 3 ? "boockmark-title-1 valign-text-middle notosanskr-bold-blueberry-35px" : "boockmark-title valign-text-middle notosanskr-bold-blueberry-35px"}
                    onClick={() => showTab(3)}
                  >
                    지식에 대한 갈망
                  </div>
                </div>
                <div className={currentTab === 4 ? "overlap-group3" : "overlap-group-2"}>
                  <div
                    className={currentTab === 4 ? "boockmark-title-1 valign-text-middle notosanskr-bold-blueberry-35px" : "boockmark-title valign-text-middle notosanskr-bold-blueberry-35px"}
                    onClick={() => showTab(4)}
                  >
                    취약한 사교 능력
                  </div>
                </div>
              </div>

              <div className="overlap-group7">
                <div className="sidebar-left sidebar"></div>
                <div className={currentTab === 1 ? "overlap-group-4" : "overlap-group-4 hidden"} id="content1">
                  <div className="main-content2-title notosanskr-bold-black-50px">소개</div>
                  <div className="overlap-group1-1">
                    <p className="main-content2-maintext notosanskr-medium-black-24px">
                      INTJ는 내성적, 직관적, 사고적, 판단적 특성을 지닌 성격 유형입니다.<br />이들은 삶의 세부사항을 완벽하게 하고, 하는 모든 일에 창의성과<br />합리성을 적용하는 것을 좋아합니다.
                    </p>
                  </div>
                </div>

                <div className={currentTab === 2 ? "overlap-group-4" : "overlap-group-4 hidden"} id="content2">
                  <div className="main-content2-title notosanskr-bold-black-50px">개척자 정신</div>
                  <div className="overlap-group1-1">
                    <p className="main-content2-maintext notosanskr-medium-black-24px">
                      INTJ는 모든 것에 의문을 제기하며, 기존의 통념과 규칙에 얽매이지 않고 자신만의 방식을 찾아내는 것을 선호합니다.
                    </p>
                  </div>
                </div>

                <div className={currentTab === 3 ? "overlap-group-4" : "overlap-group-4 hidden"} id="content3">
                  <div className="main-content2-title notosanskr-bold-black-50px">지식에 대한 갈망</div>
                  <div className="overlap-group1-1">
                    <p className="main-content2-maintext notosanskr-medium-black-24px">
                      대단한 몽상가이자 비관주의자로, 자신의 지적 능력으로 어떤 목표든 성취할 수 있다고 믿지만, 다른 사람들을 냉소적으로 보는 경향이 있습니다. 이들의 자존감은 지식과 지적 능력에 기반하며, 새로운 것을 배우는 것은 남을 위한 것이 아니라 자신을 위한 즐거움입니다.
                    </p>
                  </div>
                </div>

                <div className={currentTab === 4 ? "overlap-group-4" : "overlap-group-4 hidden"} id="content4">
                  <div className="main-content2-title notosanskr-bold-black-50px">취약한 사교 능력</div>
                  <div className="overlap-group1-1">
                    <p className="main-content2-maintext notosanskr-medium-black-24px">
                      전략가는 이성과 성공을 중시하며, 솔직함을 추구하다 보니 따뜻하고 부드러운 성격이 아닙니다. 잡담과 인사치레를 무의미하게 여겨 무례하게 보일 수 있지만, 자신과 비슷한 가치관을 지닌 사람과는 소통을 원합니다. 전략가는 자신의 관심사에 집중할 때 자신감을 발산하며, 이는 직장 동료와의 관계나 친구, 연인 관계에서 도움이 되기도 합니다.
                    </p>
                  </div>
                </div>
                <div className="sidebar-right sidebar"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MBTIPage_INTJ;

