import React from 'react';

function HomePage() {
    return (
        <div>
            <h1>메인 페이지</h1>
            <p>로그인에 성공했습니다. 여기는 홈 페이지입니다.</p>
        </div>
    );
}

export default HomePage;
